exports.handler = async function (event, context) {
  return 'Hello, World!';
};
